![banner](https://i.gyazo.com/d1e27498ee65b42783f302aaeddf29b2.png)
![description](https://i.gyazo.com/0926bf0ae23fb20f4449b6d5445fc4d8.png)

**Getting Started**  
qbot is an advanced, easy to setup, free, and unbranded Discord-Roblox ranking bot. The instructions to set it up and host it are available here: https://github.com/yogurtsyum/qbot/wiki/setup

There is currently 1 branches of qbot available:  
`master` - The latest version of qbot with many features.

**Support**  
If at any time while using qbot, you need support with it, then feel free to join our support server here: https://discord.gg/PHHrjzY.

**Other Information**  
qbot requires Node 12. If you are using https://glitch.com to host your bot, your server will automatically be updated to Node 12 because of it being specified in the package.json file.

License: https://github.com/yogurtsyum/qbot/blob/master/LICENSE  
Acknowledgements: https://github.com/yogurtsyum/qbot/blob/master/acknowledgements.md  
Contributors: https://github.com/yogurtsyum/qbot/graphs/contributors   

Please note we are not responsible for if anything happens to your bot account. It is your responsibility to keep the cookie and token away from anyone you don't trust. qbot uses noblox.js to interact with Roblox API with your bot cookie, and discord.js to interact with the Discord API with your bot token. Do not share your config.json file with anyone once filled out.
